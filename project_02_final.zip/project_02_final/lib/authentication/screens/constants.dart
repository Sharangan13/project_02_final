class Constants{

  static final String BASE_URL = 'https://fcm.googleapis.com/fcm/send';
  static final String KEY_SERVER = 'AAAAASv2UKg:APA91bFtxLkE_QR4DhnlK6LqLJhjDj0EeT8GJoDBIoa9QwhOYSG6Q6-fyTKAzivZfVUtbkYSQefQz7J10YSiSWKjTYR-4xbBvWtNrTBuWQYRtUkz1mIhszasAhfuaZJUP5nOp5QHMZGs';
  static final String SENDER_ID = '5032530088';

}