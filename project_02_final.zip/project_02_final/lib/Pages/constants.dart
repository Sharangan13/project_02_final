class Constants {
  static const String clientId =
      'AVBOuDtH0dBamB4-bKTJelNoG-QA32EZ2UfUC1DEZ8gwIqxDG-udlt9L2HBIcAkK9s8LPdyYAqGrdxtw';
  static const String secretKey =
      'EAN8QXJKSdP1Gb5dd-sq6mprCYjTc9wbMBRGfOH8KmsFsdWLhHMasfrd0EcBMEoPUAxnaRvrtWwCH6jM';
  static const String returnURL = 'https://samplesite.com/return';
  static const String cancelURL = 'https://samplesite.com/cancel';
}
